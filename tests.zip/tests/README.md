# 测试用例说明

本目录包含了AODSQL数据库系统的测试用例，用于验证核心功能。

## 测试文件

### 1. test_simple_ddl_dml.py
简化的DDL和DML功能测试，不依赖pytest，可以直接运行。

**测试内容：**
- ✅ CREATE TABLE功能测试
- ✅ INSERT数据插入测试  
- ✅ DELETE数据删除测试
- ✅ 完整工作流程测试
- ✅ 算子树构建测试
- ⚠️ 算子树可视化测试（部分功能）
- ⚠️ SQL解释器集成测试（部分功能）

**运行方法：**
```bash
python3 tests/test_simple_ddl_dml.py
```

### 2. test_ddl_dml_complete.py
完整的pytest测试套件，包含更详细的测试用例。

**运行方法：**
```bash
# 需要先安装pytest
pip install pytest
pytest tests/test_ddl_dml_complete.py -v
```

### 3. test_operators.py
算子级别的单元测试，测试各个数据库算子的功能。

## 测试覆盖的功能

### DDL (数据定义语言)
- **CREATE TABLE**: 创建表结构
  - 支持多种数据类型 (INT, VARCHAR, FLOAT等)
  - 表元数据注册到目录管理器
  - 存储引擎表文件创建

### DML (数据操作语言)
- **INSERT**: 数据插入
  - 单行和多行插入
  - 数据完整性验证
  - 自动行ID生成

- **DELETE**: 数据删除
  - 条件删除（基于WHERE子句）
  - 批量删除
  - 删除结果验证

### 查询功能
- **SeqScan**: 顺序扫描
- **Filter**: 条件过滤
- **Project**: 列投影

### 算子树功能
- **算子树构建**: 测试多级算子的链式构建和执行
- **算子树可视化**: 测试算子树的结构分析和统计
- **算子链执行**: 验证SeqScan → Filter → Project的完整查询流程

## 测试环境

测试使用模拟存储引擎 (`MockStorageEngine`)，所有数据存储在内存中，不会影响实际文件系统。

## 示例测试场景

### 完整工作流程测试
1. 创建订单表 (orders)
2. 插入5条订单记录
3. 删除特定客户的订单 (John的订单)
4. 验证删除结果
5. 再次插入新数据
6. 验证最终数据状态

### 算子树构建测试
1. 创建测试表 (test_table)
2. 插入测试数据 (Alice: 25, Bob: 30, Charlie: 35)
3. 构建查询算子树: SeqScan → Filter(age > 25) → Project(name, age)
4. 执行算子树并验证结果
5. 验证过滤和投影的正确性

### 数据验证
- 插入数据数量验证
- 删除条件正确性验证
- 剩余数据完整性验证
- 数据类型一致性验证

## 运行结果示例

```
============================================================
开始运行DDL/DML功能测试
============================================================
🧪 测试CREATE TABLE功能...
[CatalogManager]: 表 'users' 的元数据已注册。
Mock: Table 'users' created.
Mock: Creating table file for 'users'
✅ CREATE TABLE测试通过: Table 'users' created.

🧪 测试INSERT功能...
[CatalogManager]: 表 'products' 的元数据已注册。
Mock: Table 'products' created.
Mock: Creating table file for 'products'
✅ INSERT测试通过: 3 rows inserted.

🧪 测试DELETE功能...
[CatalogManager]: 表 'employees' 的元数据已注册。
Mock: Table 'employees' created.
Mock: Creating table file for 'employees'
✅ DELETE测试通过: 2 rows deleted.

🧪 测试完整工作流程...
🔄 开始完整工作流程测试...
[CatalogManager]: 表 'orders' 的元数据已注册。
Mock: Table 'orders' created.
Mock: Creating table file for 'orders'
1. 创建表: Table 'orders' created.
2. 插入数据: 5 rows inserted.
3. 验证插入: 共5条记录
4. 删除数据: 2 rows deleted.
5. 验证删除: 剩余3条记录，不包含John的订单
6. 再次插入: 2 rows inserted.
7. 最终验证: 共5条记录
✅ 完整工作流程测试通过!

🧪 测试算子树构建...
[CatalogManager]: 表 'test_table' 的元数据已注册。
Mock: Table 'test_table' created.
Mock: Creating table file for 'test_table'
✅ 算子树构建测试通过: 查询到2条记录
   结果: [('Bob', 30), ('Charlie', 35)]

🧪 测试算子树可视化...
⚠️ 算子树统计测试失败: 解释失败: 期望 ;，得到 EOF

🧪 测试SQL解释器集成...
SQL解释器结果: error
⚠️ SQL解释器返回错误: 解释失败: 期望 (，得到 )

============================================================
🎉 所有测试完成!
============================================================
```

## 注意事项

1. 测试使用模拟存储引擎，数据不会持久化
2. SQL解释器功能还在开发中，部分测试可能失败
3. 测试覆盖了核心的DDL和DML功能
4. 所有测试都是独立的，可以单独运行
